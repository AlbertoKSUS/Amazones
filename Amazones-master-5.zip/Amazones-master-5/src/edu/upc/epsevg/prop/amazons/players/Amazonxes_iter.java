/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.upc.epsevg.prop.amazons.players;

import edu.upc.epsevg.prop.amazons.CellType;
import edu.upc.epsevg.prop.amazons.GameStatus;
import edu.upc.epsevg.prop.amazons.IAuto;
import edu.upc.epsevg.prop.amazons.IPlayer;
import edu.upc.epsevg.prop.amazons.Move;
import edu.upc.epsevg.prop.amazons.SearchType;
import edu.upc.epsevg.prop.amazons.auxiliar.Heuristica;
import edu.upc.epsevg.prop.amazons.auxiliar.MiniMax;
import java.awt.Point;
import java.util.ArrayList;

/**
 *
 * @author alpez kilroig
 */
public class Amazonxes_iter implements IPlayer, IAuto {
    
    //Atributos
    private String name;
    boolean timeOut;

    // Metodos
    
    /**
     * Constructor
     * @param name 
     */
    public Amazonxes_iter(String name) {
        this.name = name;
        this.timeOut = false;
    }

    @Override
    public void timeout() {
        this.timeOut = true;
    }
    
    @Override
    public String getName() {
        return "Player(" + name + ")";
    }
    
    /**
     * Utiliza minimax para calcular el mejor movimiento possible para esa jugada.
     * @param s Estado del juego
     * @return Devuelve el mejor movimiento possible en esa jugada.
     */
    
    public Move move(GameStatus s) {
        
        int profunditat = 1;
        MiniMax res = new MiniMax(s);
        
        //Calcumen per a profunditat 1 per asegurar que tenim un resultat;
        Move millorMoviment = res.calcula(profunditat);
        
        //Mentres no s'acabi el temps...
        while (timeOut != true){
            profunditat++;
            millorMoviment = res.calcula(profunditat);
        }
        
        timeOut = false;      
        return millorMoviment;
    }
}
