/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.upc.epsevg.prop.amazons.auxiliar;

import edu.upc.epsevg.prop.amazons.CellType;
import edu.upc.epsevg.prop.amazons.GameStatus;
import edu.upc.epsevg.prop.amazons.Move;
import edu.upc.epsevg.prop.amazons.SearchType;
import java.awt.Point;
import java.util.ArrayList;

/**
 *
 * @author kilian
 */
public class MiniMax {
    
    //Atributos 
    GameStatus inicial;
    int countNodes;
    int countFulles;
    
    /**
     * 
     * @param inicial Estado inicial del movimiento.
     */
    public MiniMax(GameStatus inicial) {
        
        //Inicializacion de atributos
        this.countNodes = 0;
        this.countFulles = 0;
        this.inicial = inicial;
    }
    
    /**
     * 
     * @param profunditatMaxima Profundidad maxima en la busqueda MiniMax.
     * @return Devuelve el mejor movimiento encontrado.
     */
    public Move calcula(int profunditatMaxima) {
        
        //Variables para optimizar la poda.
        double max = Double.NEGATIVE_INFINITY;
        double alfa = Double.NEGATIVE_INFINITY;
        double beta = Double.POSITIVE_INFINITY;
        
        //Variables para guardar el mejor movimiento.
        Point mejorAmazona = new Point(0,0);
        Point destinoAmazona = new Point(0,0);
        Point mejorFlecha = new Point(0,0);
        
        //Variable para identificar al jugador
        CellType actual = inicial.getCurrentPlayer();
        
        // Calculos
             
        //Por cada amazona de la partida....
        for (int q = 0; q < inicial.getNumberOfAmazonsForEachColor(); q++) {
            
            //Obtenemos una amazona
            Point amazona = inicial.getAmazon(actual, q);
            
            //Obtenemos todos los movimientos possibles de es amazona...
            ArrayList<Point> possiblesMovimientos = inicial.getAmazonMoves(amazona, false); // -> True para simplificar y tardar menos.
            
            // Para cada possible movimiento de esa amazona...
            for(int i = 0; i < possiblesMovimientos.size(); i++){
            
                //Realizamos el movimiento de la amazona en el tablero...
                GameStatus s2 = new GameStatus(inicial);
                s2.moveAmazon(amazona, possiblesMovimientos.get(i));
                
                //Obtenemos una lista con todas las casillas libres del tablero...
                ArrayList<Point> casillasLibres = getEmptyCells(s2);
                
                //Por cada possible casilla libre en la que tirar la flecha...
                for(int r = 0; r < casillasLibres.size(); r++ ){
                    
                    //Realizamos el movimiento de tirar la flecha en el tablero...
                    GameStatus s3 = new GameStatus(inicial);
                    s3.moveAmazon(amazona, possiblesMovimientos.get(i));
                    s3.placeArrow(casillasLibres.get(r));                   
                
                    //Llamamos a la funcion minimizadora                      
                    double valor = min(s3,profunditatMaxima-1,alfa,beta);

                    //CComprobamos que el nodo actual es el mejor candidato, en caso afirmativo, guardamos la informacion del movimiento
                    if(max < valor){
                        max = valor;
                        mejorAmazona = amazona;
                        destinoAmazona = possiblesMovimientos.get(i);
                        mejorFlecha = casillasLibres.get(r);
                    }                 
                }
            }         
        }
        //Devolvemos el mejor movimiento
        return new Move(mejorAmazona,destinoAmazona,mejorFlecha,countNodes,profunditatMaxima,SearchType.MINIMAX);
    }
    
    private double min(GameStatus s, int profunditat, double alfa, double beta){
        
        //Contador de nodos explorados
        countNodes++;
        
        //Obtenemos el identificador de nuestro jugador.
        CellType actual = s.getCurrentPlayer();
        
        // Si la partida ha acabado, devolvemos infinito o -infinito dependiendo quien ha ganado
        if ( s.isGameOver()) {
            if (s.GetWinner() == actual) return Double.NEGATIVE_INFINITY;
            else return Double.POSITIVE_INFINITY;
        }
        else if ( profunditat == 0) {
            countFulles++;
            Heuristica actu = new Heuristica(s,1);
            return -actu.getHeuristica();
        }
        
        // Seguimos explorando
        
        //Valor inicial del node en +infinit
        double valorNodeActual = Double.POSITIVE_INFINITY;

        //Por cada amazona de la partida....
        for (int q = 0; q < s.getNumberOfAmazonsForEachColor(); q++) {
            
            //Obtenemos una amazona
            Point amazona = s.getAmazon(actual, q);

            //Obtenemos todos los movimientos possibles de es amazona...
            ArrayList<Point> possiblesMovimientos = s.getAmazonMoves(amazona, false); // -> True para simplificar y tardar menos.
            
            // Para cada possible movimiento de esa amazona...
            for(int i = 0; i < possiblesMovimientos.size(); i++){
            
                //Realizamos el movimiento de la amazona en el tablero...
                GameStatus s2 = new GameStatus(s);
                s2.moveAmazon(amazona, possiblesMovimientos.get(i));
                
                //Obtenemos una lista con todas las casillas libres del tablero...
                ArrayList<Point> casillasLibres = getEmptyCells(s2);
                
                //Por cada possible casilla libre en la que tirar la flecha...
                for(int r = 0; r < casillasLibres.size(); r++ ){
                    
                    //Realizamos el movimiento de tirar la flecha en el tablero...
                    GameStatus s3 = new GameStatus(s);
                    s3.moveAmazon(amazona,possiblesMovimientos.get(i));
                    s3.placeArrow(casillasLibres.get(r));                   
                
                    //Llamamos a MAX
                    valorNodeActual = Math.min(valorNodeActual, max(s3,profunditat-1,alfa,beta));
                        
                    // Ampliacio poda alfa-beta
                    alfa = Math.min(valorNodeActual,alfa);
                    if( beta <= alfa) return valorNodeActual;
                }
            }
        }
        return valorNodeActual;
    }
            
    private double max(GameStatus s, int profunditat, double alfa, double beta){
        
        //Contador de nodos explorados
        countNodes++;
        CellType actual = s.getCurrentPlayer();
        // Si la partida ha acabado, devolvemos infinito o -infinito dependiendo quien ha ganado
        if ( s.isGameOver()) {
            if (s.GetWinner() == actual) return Double.POSITIVE_INFINITY;
            else return Double.NEGATIVE_INFINITY;
        }
        else if ( profunditat == 0) {
            countFulles++;
            Heuristica actu = new Heuristica(s,1);
            return actu.getHeuristica();
        }
        
        // Seguimos explorando
        
        //Valor inicial del node en -infinit
        double valorNodeActual = Double.NEGATIVE_INFINITY;

        //Por cada amazona de la partida....
        for (int q = 0; q < s.getNumberOfAmazonsForEachColor(); q++) {
            
            //Obtenemos una amazona
            Point amazona = s.getAmazon(actual, q);
            
            //Obtenemos todos los movimientos possibles de es amazona...
            ArrayList<Point> possiblesMovimientos = s.getAmazonMoves(amazona, false); // -> True para simplificar y tardar menos.
            
            // Para cada possible movimiento de esa amazona...
            for(int i = 0; i < possiblesMovimientos.size(); i++){
            
                //Realizamos el movimiento de la amazona en el tablero...
                GameStatus s2 = new GameStatus(s);
                s2.moveAmazon(amazona, possiblesMovimientos.get(i));
                
                //Obtenemos una lista con todas las casillas libres del tablero...
                ArrayList<Point> casillasLibres = getEmptyCells(s2);
                
                //Por cada possible casilla libre en la que tirar la flecha...
                for(int r = 0; r < casillasLibres.size(); r++ ){
                    
                    //Realizamos el movimiento de tirar la flecha en el tablero...
                    GameStatus s3 = new GameStatus(s);
                    s3.moveAmazon(amazona, possiblesMovimientos.get(i));
                    s3.placeArrow(casillasLibres.get(r));                                
                
                    //Llamamos a MIN                      
                    valorNodeActual = Math.max(valorNodeActual, min(s3,profunditat-1,alfa,beta));
                        
                    // Ampliacio poda alfa-beta
                    alfa = Math.max(valorNodeActual,alfa);
                    if( beta<= alfa) return valorNodeActual;
   
                }
                //s.moveAmazon(possiblesMovimientos.get(i),amazona);
            }
        }
        return valorNodeActual;
    }
    
        /**
     * Recorremos el tablero en busca de las casillas libres
     * @param s Estado del juego
     * @return Devuelve una lista con todas las casillas libres del tablero.
     */
    public ArrayList<java.awt.Point> getEmptyCells(GameStatus s) {
        
        ArrayList<Point> emptyCells = new ArrayList<>();
        
        //Recorremos el tablero buscando casillas libres.
        for(int x = 0; x < s.getSize(); x ++) {
            for ( int y = 0; y < s.getSize(); y++) {
                if ( s.getPos(x,y) == CellType.EMPTY) {
                    //Guardamos el punto con casilla libre en el array.
                    Point p = new Point(x,y);
                    emptyCells.add(p);
                }              
            }
        }
        
         return emptyCells;    
    }
    
}
