/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.upc.epsevg.prop.amazons.players;

import edu.upc.epsevg.prop.amazons.CellType;
import edu.upc.epsevg.prop.amazons.GameStatus;
import edu.upc.epsevg.prop.amazons.IAuto;
import edu.upc.epsevg.prop.amazons.IPlayer;
import edu.upc.epsevg.prop.amazons.Move;
import edu.upc.epsevg.prop.amazons.SearchType;
import edu.upc.epsevg.prop.amazons.auxiliar.Heuristica;
import edu.upc.epsevg.prop.amazons.auxiliar.MiniMax;
import java.awt.Point;
import java.util.ArrayList;

/**
 *
 * @author alpez kilroig
 */
public class Amazonxes implements IPlayer, IAuto {

    //Atributos
    private String name;
    int profunditatMaxima;

    // Metodos
    
    /**
     * Constructor
     * @param name 
     */
    public Amazonxes(String name,int profunditatMaxima) {
        this.name = name;
        this.profunditatMaxima = profunditatMaxima;
    }

    @Override
    public void timeout() {
        // Nothing to do! I'm so fast, I never timeout 8-)
    }
    
    @Override
    public String getName() {
        return "Player(" + name + ")";
    }
    
    /**
     * Utiliza minimax para calcular el mejor movimiento possible para esa jugada.
     * @param s Estado del juego
     * @return Devuelve el mejor movimiento possible en esa jugada.
     */
    
    public Move move(GameStatus s) {
        
        MiniMax res = new MiniMax(s);
        return res.calcula(profunditatMaxima);
      
    }
}
    
