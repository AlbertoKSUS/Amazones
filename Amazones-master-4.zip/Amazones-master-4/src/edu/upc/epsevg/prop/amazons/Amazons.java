package edu.upc.epsevg.prop.amazons;

import edu.upc.epsevg.prop.amazons.players.HumanPlayer;
import edu.upc.epsevg.prop.amazons.players.CarlinhosPlayer;
import edu.upc.epsevg.prop.amazons.players.RandomPlayer;
import edu.upc.epsevg.prop.amazons.players.amazonxes;
import javax.swing.SwingUtilities;

/**
 *
 * @author bernat
 */
public class Amazons {
        /**
     * @param args
     */
    public static void main(String[] args) {
        
        
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                
                //Jugadores prueba
                //IPlayer player1 = new HumanPlayer("HumanPlayer");
                //IPlayer player1 = new CarlinhosPlayer("HumanPlayer");
                IPlayer player1 = new RandomPlayer("pacp");
                
                //Nuestro jugador
                IPlayer player2 = new amazonxes("amazonxes",2);
                
                new AmazonsBoard(player1 , player2, 10, Level.FULL_BOARD);
                
            }
        });
    }
}
